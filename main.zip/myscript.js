window.addEventListener('load', function () {
    document.getElementById("name").value = "Sriya";
    alert('Hello!')
  })